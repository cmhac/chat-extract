"""Extracts text from group chat screenshots using the OpenAI API."""

from chat_extract.extract import extract_data_from_video, ChatTextExtractor
